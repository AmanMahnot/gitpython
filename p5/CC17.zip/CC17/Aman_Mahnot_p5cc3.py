# -*- coding: utf-8 -*-
"""
Created on Wed May 16 11:45:11 2018

@author: user
"""

from PIL import Image
img = Image.open("Sample.jpg")
img = img.convert("L")
img = img.rotate(-90)
w,h = img.size
hw,hh = w/2,h/2
area=(hw-80,hh-102,hw+80,hh+102)
img = img.crop(area)
img.thumbnail((75,75))
img.show()
a=raw_input("enter the name")
img.save(a+".jpg")